import { Link } from "react-router-dom";
import { contact, navLinks } from "../data/content";

export default function Footer() {
  return (
    <footer className="bg-ink text-white">
      <div className="mx-auto max-w-[1480px] px-5 pb-10 pt-20 md:px-8 md:pt-28">
        <div className="flex flex-col gap-16 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-xl">
            <p className="text-[11px] tracking-[0.22em] uppercase text-white/40">
              Creative & Media — Lahore
            </p>
            <h2 className="mt-5 font-serif text-[18vw] leading-[0.8] tracking-[-0.04em] text-white sm:text-[12vw] lg:text-[8.4rem]">
              Pakworx
            </h2>
            <p className="mt-8 max-w-md text-[15px] leading-relaxed text-white/55">
              A studio for brands that refuse to blend in. We design identities,
              make films, and build digital worlds with a point of view.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-12 sm:grid-cols-3 lg:gap-20">
            <div>
              <p className="text-[11px] tracking-[0.18em] uppercase text-white/35">
                Navigate
              </p>
              <ul className="mt-5 space-y-2.5">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-[15px] text-white/80 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[11px] tracking-[0.18em] uppercase text-white/35">
                Studio
              </p>
              <ul className="mt-5 space-y-2.5 text-[15px] text-white/80">
                <li>
                  <a href={`mailto:${contact.email}`} className="hover:text-white">
                    {contact.email}
                  </a>
                </li>
                <li>
                  <a href={`tel:${contact.phone.replace(/\s/g, "")}`} className="hover:text-white">
                    {contact.phone}
                  </a>
                </li>
                <li>
                  {contact.location}
                  <br />
                  {contact.country}
                </li>
              </ul>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <p className="text-[11px] tracking-[0.18em] uppercase text-white/35">
                Follow
              </p>
              <ul className="mt-5 space-y-2.5 text-[15px] text-white/80">
                <li>
                  <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-white">
                    Instagram
                  </a>
                </li>
                <li>
                  <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="hover:text-white">
                    LinkedIn
                  </a>
                </li>
                <li>
                  <a href="https://behance.net" target="_blank" rel="noreferrer" className="hover:text-white">
                    Behance
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-20 flex flex-col gap-3 border-t border-white/10 pt-6 text-[12px] tracking-wide text-white/35 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Pakworx. All rights reserved.</p>
          <p>Designed and built with intent.</p>
        </div>
      </div>
    </footer>
  );
}
