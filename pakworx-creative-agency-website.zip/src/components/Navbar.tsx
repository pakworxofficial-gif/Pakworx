import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { navLinks } from "../data/content";
import { cn } from "../utils/cn";

export default function Navbar() {
  const { pathname } = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const solid = scrolled || open || pathname !== "/";

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-300",
          solid ? "bg-white/90 backdrop-blur-md" : "bg-transparent",
        )}
      >
        <div className="mx-auto flex h-16 max-w-[1480px] items-center justify-between px-5 md:h-[76px] md:px-8">
          <Link to="/" className="group flex items-center gap-2.5">
            <span className="relative flex h-6 w-6 items-center justify-center">
              <span className="absolute inset-0 rotate-45 rounded-[5px] bg-ink transition-colors group-hover:bg-accent" />
              <span className="relative h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            <span className="text-[17px] font-medium tracking-[-0.03em] text-ink">Pakworx</span>
          </Link>

          <nav className="hidden items-center gap-8 lg:flex">
            {navLinks.map((link) => {
              const active = pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "relative text-[13px] tracking-[0.08em] uppercase transition-colors",
                    active ? "text-ink" : "text-mute hover:text-ink",
                  )}
                >
                  {link.label}
                  {active && (
                    <span className="absolute -bottom-1.5 left-0 h-px w-full bg-accent" />
                  )}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-4">
            <Link
              to="/contact"
              className="group hidden items-center gap-2 text-[13px] font-medium tracking-[-0.01em] text-ink md:inline-flex"
            >
              Let’s Talk
              <span className="transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5">
                ↗
              </span>
            </Link>
            <button
              type="button"
              aria-label={open ? "Close menu" : "Open menu"}
              onClick={() => setOpen((v) => !v)}
              className="relative flex h-10 w-10 items-center justify-center lg:hidden"
            >
              <span
                className={cn(
                  "absolute h-px w-5 bg-ink transition-all duration-300",
                  open ? "translate-y-0 rotate-45" : "-translate-y-1.5",
                )}
              />
              <span
                className={cn(
                  "absolute h-px w-5 bg-ink transition-all duration-300",
                  open ? "translate-y-0 -rotate-45" : "translate-y-1.5",
                )}
              />
            </button>
          </div>
        </div>
      </header>

      <div
        className={cn(
          "fixed inset-0 z-40 bg-paper transition-all duration-500 lg:hidden",
          open ? "visible opacity-100" : "invisible opacity-0",
        )}
      >
        <div className="flex h-full flex-col justify-between px-6 pb-10 pt-28">
          <nav className="flex flex-col">
            {navLinks.map((link, i) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "border-b border-stone py-4 font-serif text-5xl tracking-tight",
                  pathname === link.path ? "text-accent" : "text-ink",
                )}
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 text-sm tracking-[0.12em] uppercase"
          >
            Let’s Talk ↗
          </Link>
        </div>
      </div>
    </>
  );
}
