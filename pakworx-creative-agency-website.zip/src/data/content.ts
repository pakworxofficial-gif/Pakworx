export const navLinks = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Services", path: "/services" },
  { label: "Portfolio", path: "/portfolio" },
  { label: "Blog", path: "/blog" },
  { label: "Contact", path: "/contact" },
];

export const contact = {
  email: "hello@pakworx.com",
  phone: "+92 300 848 2910",
  location: "Gulberg III, Lahore",
  country: "Pakistan",
};

export const capabilities = [
  "Video",
  "Design",
  "Branding",
  "Digital",
  "Content",
  "Growth",
  "Direction",
  "Strategy",
];

export const services = [
  {
    id: "video",
    index: "01",
    name: "Video",
    tagline: "Moving images with a point of view.",
    what: "Film, campaign films, brand films, documentaries, and social motion. We treat video as a craft — not a content quota.",
    delivers: [
      "Brand and campaign films",
      "Documentary and reportage",
      "Social and short-form motion",
      "Direction, production, and post",
    ],
    why: "A still can introduce you. A film can make someone stay. Video is how a brand becomes a feeling people remember after they leave the room.",
    image:
      "https://images.pexels.com/photos/23384400/pexels-photo-23384400.jpeg?auto=compress&cs=tinysrgb&w=1600",
  },
  {
    id: "design",
    index: "02",
    name: "Design",
    tagline: "Form that carries meaning.",
    what: "Visual systems, editorial design, packaging, and digital interfaces. Design at Pakworx is not decoration — it is how an idea becomes visible.",
    delivers: [
      "Art direction and visual systems",
      "Editorial and print",
      "Packaging and object design",
      "Digital product and web design",
    ],
    why: "People decide how they feel about you before they read a word. Design is that first sentence — and every one after it.",
    image:
      "https://images.pexels.com/photos/8546649/pexels-photo-8546649.jpeg?auto=compress&cs=tinysrgb&w=1600",
  },
  {
    id: "branding",
    index: "03",
    name: "Branding",
    tagline: "Identity with a spine.",
    what: "Names, marks, verbal identity, and the systems that hold a brand together over years — not a logo dropped into a template.",
    delivers: [
      "Positioning and narrative",
      "Naming and verbal identity",
      "Marks, type, and color systems",
      "Brand books and launch kits",
    ],
    why: "A brand is the only asset that compounds when the campaign ends. Built well, it becomes the reason people choose you twice.",
    image: "/images/brand-system.jpg",
  },
  {
    id: "digital",
    index: "04",
    name: "Digital",
    tagline: "Experiences that feel considered.",
    what: "Websites, product surfaces, and digital campaigns. We build digital that behaves like a well-made object — quiet, precise, and hard to leave.",
    delivers: [
      "Websites and microsites",
      "Campaign platforms",
      "Product and interface design",
      "Front-end craft",
    ],
    why: "Most digital is loud and forgettable. The work that lasts is the work that respects attention.",
    image: "/images/card-design.jpg",
  },
  {
    id: "content",
    index: "05",
    name: "Content",
    tagline: "A voice, not a feed.",
    what: "Ongoing content systems for brands that want a point of view. Photography, social, editorial, and the calendar that holds it together.",
    delivers: [
      "Content strategy and voice",
      "Photography and social systems",
      "Editorial series",
      "Production rhythms",
    ],
    why: "Content without a spine is just noise. A system with taste becomes the brand people return to.",
    image: "/images/social-campaign.jpg",
  },
  {
    id: "growth",
    index: "06",
    name: "Growth",
    tagline: "Attention, then traction.",
    what: "Media thinking, launch strategy, and the work that sits between a beautiful idea and an audience that actually sees it.",
    delivers: [
      "Launch and campaign strategy",
      "Channel thinking",
      "Creative media concepts",
      "Performance-aware storytelling",
    ],
    why: "Craft without reach is a private exercise. Growth without craft is a race to the bottom. We hold both.",
    image:
      "https://images.pexels.com/photos/8360497/pexels-photo-8360497.jpeg?auto=compress&cs=tinysrgb&w=1600",
  },
];

export const projects = [
  {
    id: "atelier-noir",
    name: "Atelier Noir",
    category: "Branding",
    year: "2025",
    size: "large" as const,
    description:
      "A complete identity for a fragrance house — mark, type, packaging language, and the still-life world around it.",
    image: "/images/brand-system.jpg",
    secondary:
      "https://images.pexels.com/photos/11216321/pexels-photo-11216321.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "still-moving",
    name: "Still / Moving",
    category: "Video",
    year: "2025",
    size: "small" as const,
    description:
      "A concert film built around silence as much as sound. One night, one stage, no spectacle for its own sake.",
    image:
      "https://images.pexels.com/photos/30518233/pexels-photo-30518233.jpeg?auto=compress&cs=tinysrgb&w=1600",
    secondary:
      "https://images.pexels.com/photos/11963130/pexels-photo-11963130.png?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "velvet-hour",
    name: "Velvet Hour",
    category: "Content",
    year: "2024",
    size: "tall" as const,
    description:
      "A seasonal lookbook and social system for a fashion house. Color as character. Light as the only prop.",
    image:
      "https://images.pexels.com/photos/33714925/pexels-photo-33714925.jpeg?auto=compress&cs=tinysrgb&w=1200",
    secondary:
      "https://images.pexels.com/photos/8004390/pexels-photo-8004390.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "salt-form",
    name: "Salt & Form",
    category: "Design",
    year: "2025",
    size: "wide" as const,
    description:
      "Identity, menus, and food photography for a restaurant that wanted the plate to do the talking.",
    image:
      "https://images.pexels.com/photos/24186303/pexels-photo-24186303.jpeg?auto=compress&cs=tinysrgb&w=1600",
    secondary:
      "https://images.pexels.com/photos/29168406/pexels-photo-29168406.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "house-amber",
    name: "House of Amber",
    category: "Branding",
    year: "2024",
    size: "small" as const,
    description:
      "Packaging and object design for a perfume line. Dark glass, quiet type, nothing extra.",
    image:
      "https://images.pexels.com/photos/32630380/pexels-photo-32630380.jpeg?auto=compress&cs=tinysrgb&w=1200",
    secondary:
      "https://images.pexels.com/photos/11711830/pexels-photo-11711830.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "frame-notes",
    name: "Frame Notes",
    category: "Video",
    year: "2024",
    size: "wide" as const,
    description:
      "Title sequence and visual language for a documentary series about craft in South Asia.",
    image:
      "https://images.pexels.com/photos/19224452/pexels-photo-19224452.jpeg?auto=compress&cs=tinysrgb&w=1600",
    secondary:
      "https://images.pexels.com/photos/30396798/pexels-photo-30396798.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    id: "paper-study",
    name: "Paper Study",
    category: "Design",
    year: "2025",
    size: "small" as const,
    description:
      "An editorial type system and print series exploring how a single family of letters can carry a whole voice.",
    image: "/images/type-specimen.jpg",
    secondary: "/images/card-branding.jpg",
  },
  {
    id: "night-market",
    name: "Night Market",
    category: "Digital",
    year: "2025",
    size: "large" as const,
    description:
      "A campaign platform and social system for a city-wide cultural series. Digital that feels like a printed object.",
    image: "/images/social-campaign.jpg",
    secondary: "/images/card-content.jpg",
  },
];

export const articles = [
  {
    id: "brands-fail-feeling",
    title: "Why brands fail when they skip the feeling",
    excerpt:
      "Most identities die of politeness. They are correct, complete, and completely forgettable. Feeling is not a luxury — it is the work.",
    category: "Branding",
    date: "12 Mar 2026",
    read: "7 min",
    featured: true,
    image:
      "https://images.pexels.com/photos/11216321/pexels-photo-11216321.jpeg?auto=compress&cs=tinysrgb&w=1600",
    body: [
      "A brand that only explains itself is already losing. People do not remember a list of values. They remember a temperature — the way something looked in a doorway, the sound of a sentence, the weight of a card in the hand.",
      "We see this most clearly in categories that have professionalized themselves into sameness. The same sans-serif. The same desaturated photography. The same claim of authenticity. The work is competent. The work does not stay.",
      "Feeling is not decoration added at the end. It is a decision made at the beginning: what should this be like to encounter? That question is more useful than a moodboard. It forces a point of view.",
      "At Pakworx we start there. Not with a logo. Not with a color. With a feeling we can defend — and then we build the system that can carry it for years.",
    ],
  },
  {
    id: "single-typeface",
    title: "The quiet power of a single typeface",
    excerpt:
      "Restraint is not a lack of ideas. Sometimes the most confident system is one family of letters, used with complete conviction.",
    category: "Design",
    date: "28 Feb 2026",
    read: "5 min",
    featured: false,
    image: "/images/type-specimen.jpg",
    body: [
      "Type is the closest thing a brand has to a speaking voice. Change the family and you change who is talking.",
      "We often recommend using fewer typefaces, not more. A single well-chosen family — with enough weights and a proper italic — can carry identity, editorial, packaging, and interface without shouting.",
      "The work is in the details: the tracking of a headline, the measure of a paragraph, the decision to let a word sit alone on a line. That is where a brand becomes itself.",
    ],
  },
  {
    id: "shooting-stillness",
    title: "Shooting for stillness in a noisy feed",
    excerpt:
      "Social does not require speed. It requires a frame someone would pause for. Stillness is a strategy.",
    category: "Content",
    date: "09 Feb 2026",
    read: "6 min",
    featured: false,
    image:
      "https://images.pexels.com/photos/28863302/pexels-photo-28863302.jpeg?auto=compress&cs=tinysrgb&w=1400",
    body: [
      "Feeds reward motion. That does not mean every frame has to twitch. The images people save are often the quiet ones — a face, a table, a color held long enough to become a mood.",
      "When we build content systems we design for pause, not just scroll. That means lighting with intent, cropping with discipline, and refusing the template that makes every brand look like every other brand.",
    ],
  },
  {
    id: "strategy-creative-act",
    title: "Strategy is a creative act",
    excerpt:
      "A strategy deck that cannot be felt is not finished. The best thinking arrives as an image, a line, a constraint.",
    category: "Branding",
    date: "21 Jan 2026",
    read: "8 min",
    featured: false,
    image:
      "https://images.pexels.com/photos/3850210/pexels-photo-3850210.jpeg?auto=compress&cs=tinysrgb&w=1400",
    body: [
      "We do not separate the people who think from the people who make. Strategy that cannot survive contact with a camera or a typesetting file is not strategy — it is a document.",
      "The useful questions are simple. Who is this for. What should they feel. What will we refuse. Those answers become the work.",
    ],
  },
  {
    id: "what-we-look-for",
    title: "What we look for in a brief",
    excerpt:
      "A good brief is not a list of deliverables. It is a tension, a problem, a reason the work needs to exist.",
    category: "Digital",
    date: "04 Jan 2026",
    read: "4 min",
    featured: false,
    image: "/images/card-design.jpg",
    body: [
      "We are less interested in the number of pages than in the reason the pages need to exist. A brief that only describes output leaves the studio guessing at meaning.",
      "Bring us the tension. The audience you cannot reach. The thing you are afraid to say. That is where the work starts.",
    ],
  },
  {
    id: "digital-not-digital",
    title: "Digital that doesn't feel digital",
    excerpt:
      "The best websites feel like objects. Weight, paper, pause — translated into a screen without losing their body.",
    category: "Digital",
    date: "18 Dec 2025",
    read: "6 min",
    featured: false,
    image:
      "https://images.pexels.com/photos/9903143/pexels-photo-9903143.jpeg?auto=compress&cs=tinysrgb&w=1400",
    body: [
      "Screens flatten everything. Our job is to put some of the body back — through type, spacing, motion that behaves like a hand, not a bounce.",
      "We design digital the way we design print. Hierarchy first. Then material. Then the one gesture that makes it feel considered.",
    ],
  },
  {
    id: "lahore-as-context",
    title: "Lahore as a creative context",
    excerpt:
      "We work from a city with a long memory for craft, ceremony, and spectacle. That history is not a backdrop. It is a resource.",
    category: "Content",
    date: "02 Dec 2025",
    read: "7 min",
    featured: false,
    image:
      "https://images.pexels.com/photos/13629907/pexels-photo-13629907.jpeg?auto=compress&cs=tinysrgb&w=1600",
    body: [
      "Lahore knows how to hold a crowd and how to hold a silence. That double knowledge — ceremony and intimacy — sits under everything we make.",
      "We do not perform 'local color' for a global audience. We use the city's sense of scale, ornament, and gathering as a way of thinking about brands that need to feel alive.",
    ],
  },
  {
    id: "on-art-direction",
    title: "Art direction is a series of refusals",
    excerpt:
      "Taste is not what you add. It is what you will not allow in the frame.",
    category: "Design",
    date: "11 Nov 2025",
    read: "5 min",
    featured: false,
    image:
      "https://images.pexels.com/photos/19222080/pexels-photo-19222080.jpeg?auto=compress&cs=tinysrgb&w=1400",
    body: [
      "Every frame is a set of decisions about what is not there. The unused color. The cropped gesture. The type that was almost chosen.",
      "When a project feels expensive, it is usually because someone said no enough times for the yes to become obvious.",
    ],
  },
];

export const team = [
  {
    name: "Ali Amjad",
    role: "CEO",
    bio: "Ali leads the studio. He holds the relationship between ambition and craft — making sure the work is both possible and worth doing.",
    image:
      "https://images.pexels.com/photos/17685845/pexels-photo-17685845.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    name: "Umais Baig",
    role: "CCO",
    bio: "Umais is chief creative officer. He sets the taste of the room — the standard against which every frame, word, and mark is judged.",
    image:
      "https://images.pexels.com/photos/13273039/pexels-photo-13273039.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
  {
    name: "Ammaz Baig",
    role: "CTO",
    bio: "Ammaz leads technology. He turns ideas into systems that hold — digital products, platforms, and the craft of making them feel inevitable.",
    image:
      "https://images.pexels.com/photos/7580990/pexels-photo-7580990.jpeg?auto=compress&cs=tinysrgb&w=1200",
  },
];

export const philosophy = [
  {
    num: "01",
    title: "Creative",
    text: "Taste is a discipline. We start with a feeling we can name, then we find the form that can carry it. Nothing decorative. Nothing borrowed.",
  },
  {
    num: "02",
    title: "Strategy",
    text: "A beautiful thing that cannot be defended will not last. We ask what the work is for, who it is for, and what we are willing to refuse.",
  },
  {
    num: "03",
    title: "Execution",
    text: "Ideas are cheap until they meet a camera, a press, or a screen. We stay with the work until it is made — properly, and all the way through.",
  },
];
