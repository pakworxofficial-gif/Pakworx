import { Link } from "react-router-dom";
import Reveal from "../components/Reveal";
import { philosophy, team } from "../data/content";

export default function About() {
  return (
    <div className="page-enter bg-paper">
      <section className="mx-auto max-w-[1480px] px-5 pb-8 pt-32 md:px-8 md:pt-40">
        <p className="text-[11px] tracking-[0.22em] uppercase text-mute">About</p>
        <h1 className="mt-6 max-w-5xl font-serif text-[16vw] leading-[0.86] tracking-[-0.04em] text-ink sm:text-7xl md:text-8xl lg:text-[120px]">
          We are
          <br />
          <em className="italic">Pakworx.</em>
        </h1>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 pb-24 md:px-8">
        <div className="grid items-end gap-12 md:grid-cols-12">
          <Reveal className="md:col-span-5">
            <p className="text-[18px] leading-[1.7] text-ink/85 md:text-[20px]">
              A creative and media studio in Lahore. We work with people who
              want their brand to feel like something — not look like everyone.
            </p>
          </Reveal>
          <Reveal delay={100} className="md:col-span-6 md:col-start-7">
            <div className="overflow-hidden rounded-2xl">
              <img
                src="https://images.pexels.com/photos/4348298/pexels-photo-4348298.jpeg?auto=compress&cs=tinysrgb&w=1600"
                alt="Studio table with sketches and tools"
                className="aspect-[16/10] w-full object-cover"
              />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="border-y border-stone">
        <div className="mx-auto grid max-w-[1480px] gap-16 px-5 py-24 md:grid-cols-12 md:px-8 md:py-32">
          <div className="md:col-span-4">
            <p className="sticky top-28 text-[11px] tracking-[0.22em] uppercase text-mute">
              The studio
            </p>
          </div>
          <div className="space-y-8 md:col-span-7 md:col-start-6">
            <Reveal>
              <p className="font-serif text-3xl leading-snug tracking-tight text-ink md:text-4xl">
                We started Pakworx because too much creative work was either
                loud or empty. We wanted a third way — considered, human, and
                finished.
              </p>
            </Reveal>
            <Reveal delay={80}>
              <p className="text-[17px] leading-[1.75] text-mute">
                The studio sits in Lahore, a city that understands spectacle and
                intimacy in the same breath. That tension — ceremony and
                closeness — shapes how we think about brands. We do not perform
                “local color.” We use a long memory for craft as a way of
                working.
              </p>
            </Reveal>
            <Reveal delay={120}>
              <p className="text-[17px] leading-[1.75] text-mute">
                We are small on purpose. Ali holds the studio. Umais holds the
                taste. Ammaz holds the systems. Around them, a network of
                directors, designers, writers, and editors who know when to push
                and when to stop.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 py-24 md:px-8 md:py-32">
        <Reveal>
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Philosophy</p>
          <h2 className="mt-4 max-w-3xl font-serif text-5xl tracking-tight md:text-6xl">
            Three words we return to.
          </h2>
        </Reveal>

        <div className="mt-20 space-y-0">
          {philosophy.map((item, i) => (
            <Reveal key={item.title}>
              <article
                className={`grid gap-8 border-t border-stone py-14 md:grid-cols-12 md:py-20 ${
                  i === philosophy.length - 1 ? "border-b" : ""
                }`}
              >
                <span className="font-serif text-6xl text-accent/70 md:col-span-2">
                  {item.num}
                </span>
                <h3 className="font-serif text-4xl md:col-span-3 md:text-5xl">{item.title}</h3>
                <p className="max-w-xl text-[17px] leading-[1.75] text-mute md:col-span-7 md:text-[18px]">
                  {item.text} We keep these three in the same room. Creative
                  without strategy is a mood. Strategy without execution is a
                  slide. Execution without taste is just output.
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-mist">
        <div className="mx-auto max-w-[1480px] px-5 py-24 md:px-8 md:py-32">
          <Reveal>
            <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Leadership</p>
            <h2 className="mt-4 font-serif text-5xl tracking-tight md:text-6xl">
              The people who
              <br />
              hold the room.
            </h2>
          </Reveal>

          <div className="mt-16 space-y-24">
            {team.map((person, i) => {
              const reverse = i % 2 === 1;
              return (
                <Reveal key={person.name}>
                  <article
                    className={`grid items-center gap-10 md:grid-cols-12 md:gap-16 ${
                      reverse ? "" : ""
                    }`}
                  >
                    <div className={`md:col-span-6 ${reverse ? "md:order-2" : ""}`}>
                      <div className="overflow-hidden rounded-2xl bg-stone">
                        <img
                          src={person.image}
                          alt={person.name}
                          className="aspect-[4/5] w-full object-cover object-top grayscale transition duration-700 hover:grayscale-0"
                        />
                      </div>
                    </div>
                    <div className={`md:col-span-5 ${reverse ? "md:order-1" : "md:col-start-8"}`}>
                      <p className="text-[12px] tracking-[0.2em] uppercase text-accent">
                        {person.role}
                      </p>
                      <h3 className="mt-3 font-serif text-5xl tracking-tight md:text-6xl">
                        {person.name}
                      </h3>
                      <p className="mt-6 max-w-md text-[17px] leading-[1.75] text-mute">
                        {person.bio}
                      </p>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      <section className="relative isolate overflow-hidden">
        <img
          src="https://images.pexels.com/photos/13629907/pexels-photo-13629907.jpeg?auto=compress&cs=tinysrgb&w=2000"
          alt="Badshahi Mosque, Lahore"
          className="h-[70vh] w-full object-cover"
        />
        <div className="absolute inset-0 bg-ink/45" />
        <div className="absolute inset-0 flex flex-col justify-end px-5 pb-12 md:px-12 md:pb-16">
          <p className="text-[11px] tracking-[0.22em] uppercase text-white/70">From</p>
          <h2 className="mt-3 font-serif text-5xl text-white md:text-7xl">Lahore, Pakistan</h2>
          <p className="mt-4 max-w-md text-[16px] leading-relaxed text-white/80">
            A city with a long memory for gathering, craft, and ceremony. We
            work from here, and we work everywhere the work needs to go.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 py-24 text-center md:px-8 md:py-32">
        <Reveal>
          <h2 className="font-serif text-4xl tracking-tight md:text-6xl">
            If this sounds like
            <br />
            how you want to work —
          </h2>
          <Link
            to="/contact"
            className="mt-10 inline-flex items-center gap-2 text-[15px] tracking-[0.08em] uppercase text-accent"
          >
            Write to us ↗
          </Link>
        </Reveal>
      </section>
    </div>
  );
}
