import { Link, useParams } from "react-router-dom";
import { articles } from "../data/content";

export default function Article() {
  const { id } = useParams();
  const article = articles.find((a) => a.id === id);
  const more = articles.filter((a) => a.id !== id).slice(0, 3);

  if (!article) {
    return (
      <div className="page-enter mx-auto max-w-3xl px-5 py-40">
        <h1 className="font-serif text-5xl">Article not found.</h1>
        <Link to="/blog" className="mt-6 inline-block text-accent">
          Back to journal ↗
        </Link>
      </div>
    );
  }

  return (
    <div className="page-enter bg-paper">
      <article>
        <header className="mx-auto max-w-3xl px-5 pb-10 pt-32 md:pt-40">
          <p className="text-[11px] tracking-[0.22em] uppercase text-accent">{article.category}</p>
          <h1 className="mt-5 font-serif text-5xl leading-[1.05] tracking-tight md:text-6xl">
            {article.title}
          </h1>
          <p className="mt-6 text-[15px] text-mute">
            {article.date} · {article.read} read
          </p>
        </header>

        <div className="mx-auto max-w-5xl px-5">
          <img
            src={article.image}
            alt={article.title}
            className="aspect-[16/9] w-full rounded-2xl object-cover"
          />
        </div>

        <div className="mx-auto max-w-2xl px-5 py-16 md:py-20">
          <p className="font-serif text-2xl leading-snug text-ink md:text-[28px]">
            {article.excerpt}
          </p>
          <div className="mt-10 space-y-6">
            {article.body.map((para) => (
              <p key={para.slice(0, 24)} className="text-[17px] leading-[1.8] text-ink/80">
                {para}
              </p>
            ))}
          </div>
          <p className="mt-14 border-t border-stone pt-8 text-[14px] text-mute">
            Written by the studio at Pakworx, Lahore.
          </p>
        </div>
      </article>

      <section className="border-t border-stone bg-mist">
        <div className="mx-auto max-w-[1480px] px-5 py-20 md:px-8">
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Continue</p>
          <div className="mt-10 grid gap-10 md:grid-cols-3">
            {more.map((item) => (
              <Link key={item.id} to={`/blog/${item.id}`} className="group">
                <img
                  src={item.image}
                  alt={item.title}
                  className="aspect-[16/10] w-full rounded-xl object-cover"
                />
                <h3 className="mt-4 font-serif text-2xl leading-tight group-hover:text-accent">
                  {item.title}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
