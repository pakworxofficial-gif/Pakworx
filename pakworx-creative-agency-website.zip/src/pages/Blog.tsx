import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { articles } from "../data/content";
import { cn } from "../utils/cn";

const filters = ["All", "Branding", "Design", "Content", "Digital"] as const;

export default function Blog() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const featured = articles.find((a) => a.featured) ?? articles[0];
  const list = useMemo(
    () =>
      articles.filter((a) => {
        if (a.id === featured.id && filter === "All") return false;
        if (filter === "All") return true;
        return a.category === filter;
      }),
    [filter, featured.id],
  );

  return (
    <div className="page-enter bg-paper">
      <section className="border-b border-stone">
        <div className="mx-auto max-w-[1480px] px-5 pb-6 pt-32 md:px-8 md:pt-40">
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Journal</p>
          <h1 className="mt-4 font-serif text-[15vw] leading-[0.86] tracking-[-0.04em] sm:text-7xl md:text-8xl">
            Notes on
            <br />
            making.
          </h1>
        </div>
      </section>

      {filter === "All" && (
        <section className="border-b border-stone">
          <Link
            to={`/blog/${featured.id}`}
            className="group mx-auto grid max-w-[1480px] items-stretch md:grid-cols-12"
          >
            <div className="overflow-hidden md:col-span-7">
              <img
                src={featured.image}
                alt={featured.title}
                className="h-[52vh] min-h-[360px] w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
              />
            </div>
            <div className="flex flex-col justify-center px-5 py-12 md:col-span-5 md:px-12">
              <p className="text-[11px] tracking-[0.2em] uppercase text-accent">
                Featured · {featured.category}
              </p>
              <h2 className="mt-5 font-serif text-4xl leading-[1.05] tracking-tight md:text-5xl">
                {featured.title}
              </h2>
              <p className="mt-5 max-w-md text-[16px] leading-relaxed text-mute">
                {featured.excerpt}
              </p>
              <p className="mt-8 text-[13px] tracking-wide text-mute">
                {featured.date} · {featured.read}
              </p>
            </div>
          </Link>
        </section>
      )}

      <section className="mx-auto max-w-[1480px] px-5 py-10 md:px-8">
        <div className="flex flex-wrap gap-2">
          {filters.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setFilter(item)}
              className={cn(
                "rounded-full border px-4 py-1.5 text-[12px] tracking-[0.12em] uppercase transition-colors",
                filter === item
                  ? "border-ink bg-ink text-white"
                  : "border-stone text-mute hover:border-ink hover:text-ink",
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 pb-24 md:px-8 md:pb-32">
        <div className="grid gap-x-8 gap-y-16 md:grid-cols-2 lg:grid-cols-3">
          {list.map((article) => (
            <Link key={article.id} to={`/blog/${article.id}`} className="group">
              <div className="overflow-hidden rounded-xl bg-mist">
                <img
                  src={article.image}
                  alt={article.title}
                  className="aspect-[16/11] w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                />
              </div>
              <p className="mt-5 text-[11px] tracking-[0.18em] uppercase text-accent">
                {article.category}
              </p>
              <h3 className="mt-2 font-serif text-[28px] leading-tight tracking-tight transition-colors group-hover:text-accent">
                {article.title}
              </h3>
              <p className="mt-3 text-[14px] leading-relaxed text-mute">{article.excerpt}</p>
              <p className="mt-4 text-[12px] tracking-wide text-mute">
                {article.date} · {article.read}
              </p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
