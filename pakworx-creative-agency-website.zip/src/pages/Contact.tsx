import { FormEvent, useState } from "react";
import { contact, services } from "../data/content";

export default function Contact() {
  const [sent, setSent] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="page-enter bg-paper">
      <section className="mx-auto grid min-h-screen max-w-[1480px] items-start gap-16 px-5 pb-24 pt-32 md:grid-cols-12 md:px-8 md:pt-40">
        <div className="md:col-span-5">
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Contact</p>
          <h1 className="mt-5 font-serif text-[18vw] leading-[0.82] tracking-[-0.045em] sm:text-7xl md:text-8xl lg:text-[110px]">
            Let’s
            <br />
            talk.
          </h1>
          <p className="mt-8 max-w-sm text-[16px] leading-relaxed text-mute">
            Tell us what you’re making, or what you can’t quite name yet. We’ll
            read it carefully.
          </p>

          <dl className="mt-14 space-y-8">
            <div>
              <dt className="text-[11px] tracking-[0.18em] uppercase text-mute">Email</dt>
              <dd className="mt-2">
                <a href={`mailto:${contact.email}`} className="text-[18px] hover:text-accent">
                  {contact.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-[11px] tracking-[0.18em] uppercase text-mute">Phone</dt>
              <dd className="mt-2">
                <a
                  href={`tel:${contact.phone.replace(/\s/g, "")}`}
                  className="text-[18px] hover:text-accent"
                >
                  {contact.phone}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-[11px] tracking-[0.18em] uppercase text-mute">Studio</dt>
              <dd className="mt-2 text-[18px]">
                {contact.location}
                <br />
                {contact.country}
              </dd>
            </div>
          </dl>
        </div>

        <div className="md:col-span-6 md:col-start-7 md:pt-16">
          {sent ? (
            <div className="rounded-2xl bg-mist px-8 py-16">
              <p className="font-serif text-4xl">Received.</p>
              <p className="mt-4 max-w-sm text-[16px] leading-relaxed text-mute">
                Thank you. Someone from the studio will write back. If it’s
                urgent, call us.
              </p>
              <button
                type="button"
                onClick={() => setSent(false)}
                className="mt-8 text-[13px] tracking-[0.12em] uppercase text-accent"
              >
                Send another
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-8">
              <Field label="Name" name="name" type="text" required />
              <Field label="Email" name="email" type="email" required />
              <Field label="Phone" name="phone" type="tel" />
              <label className="block">
                <span className="text-[11px] tracking-[0.18em] uppercase text-mute">Service</span>
                <select
                  name="service"
                  defaultValue=""
                  required
                  className="mt-3 w-full appearance-none border-b border-stone bg-transparent py-3 text-[16px] text-ink"
                >
                  <option value="" disabled>
                    Select a discipline
                  </option>
                  {services.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                  <option value="Not sure">Not sure yet</option>
                </select>
              </label>
              <label className="block">
                <span className="text-[11px] tracking-[0.18em] uppercase text-mute">
                  Project details
                </span>
                <textarea
                  name="details"
                  required
                  rows={5}
                  placeholder="What are you trying to make, and why now?"
                  className="mt-3 w-full resize-none border-b border-stone bg-transparent py-3 text-[16px] placeholder:text-mute/50"
                />
              </label>
              <button
                type="submit"
                className="rounded-full bg-ink px-8 py-3.5 text-[13px] tracking-[0.12em] uppercase text-white transition-colors hover:bg-accent"
              >
                Send message
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  name,
  type,
  required,
}: {
  label: string;
  name: string;
  type: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-[11px] tracking-[0.18em] uppercase text-mute">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        className="mt-3 w-full border-b border-stone bg-transparent py-3 text-[16px]"
      />
    </label>
  );
}
