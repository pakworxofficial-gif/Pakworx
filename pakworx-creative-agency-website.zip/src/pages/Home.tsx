import { Link } from "react-router-dom";
import Reveal from "../components/Reveal";
import { capabilities, philosophy, projects, services } from "../data/content";

const floating = [
  {
    src: "/images/card-branding.jpg",
    label: "Branding",
    className:
      "float-a left-[4%] top-[16%] hidden w-[168px] sm:block lg:left-[7%] lg:top-[18%] lg:w-[200px] xl:w-[220px]",
  },
  {
    src: "/images/card-video.jpg",
    label: "Video",
    className:
      "float-b right-[5%] top-[14%] hidden w-[168px] sm:block lg:right-[8%] lg:top-[16%] lg:w-[200px] xl:w-[220px]",
  },
  {
    src: "/images/card-design.jpg",
    label: "Design",
    className:
      "float-c bottom-[12%] left-[8%] hidden w-[150px] md:block lg:bottom-[14%] lg:left-[14%] lg:w-[180px] xl:w-[196px]",
  },
  {
    src: "/images/card-content.jpg",
    label: "Content",
    className:
      "float-d bottom-[11%] right-[7%] hidden w-[150px] md:block lg:bottom-[13%] lg:right-[13%] lg:w-[180px] xl:w-[196px]",
  },
];

const previewServices = services.slice(0, 4);

export default function Home() {
  return (
    <div className="page-enter bg-paper">
      <section className="px-3 pt-3 md:px-4 md:pt-4">
        <div className="relative isolate overflow-hidden rounded-[28px] bg-mist md:rounded-[40px]">
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute left-1/2 top-[18%] h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-accent/20 blur-[120px]" />
            <div className="absolute -left-20 bottom-10 h-64 w-64 rounded-full bg-accent/10 blur-[90px]" />
            <div className="absolute -right-10 top-24 h-52 w-52 rounded-full bg-accent/10 blur-[80px]" />
          </div>

          {floating.map((card) => (
            <figure
              key={card.label}
              className={`absolute z-10 overflow-hidden rounded-2xl bg-white shadow-[0_24px_60px_-24px_rgba(10,10,10,0.35)] ring-1 ring-black/5 ${card.className}`}
            >
              <img src={card.src} alt={card.label} className="aspect-[4/5] w-full object-cover" />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/55 to-transparent px-3 pb-3 pt-8 text-[11px] tracking-[0.16em] uppercase text-white">
                {card.label}
              </figcaption>
            </figure>
          ))}

          <div className="relative z-20 mx-auto flex min-h-[92vh] max-w-4xl flex-col items-center justify-center px-6 py-32 text-center md:py-40">
            <p className="text-[11px] tracking-[0.28em] uppercase text-mute">
              Creative & Media · Lahore
            </p>
            <h1 className="mt-7 font-serif text-[16vw] leading-[0.88] tracking-[-0.035em] text-ink sm:text-[12vw] md:text-[92px] lg:text-[108px]">
              We make work
              <br />
              that earns a
              <br />
              <em className="italic">second look.</em>
            </h1>
            <p className="mt-8 max-w-md text-[16px] leading-relaxed text-mute md:text-[17px]">
              Pakworx is a creative and media studio. Brand, film, design, and
              digital — made with intent, for people who take culture seriously.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
              <Link
                to="/portfolio"
                className="rounded-full bg-ink px-6 py-3 text-[13px] tracking-[0.08em] uppercase text-white transition-colors hover:bg-accent"
              >
                See the work
              </Link>
              <Link
                to="/contact"
                className="rounded-full border border-ink/15 px-6 py-3 text-[13px] tracking-[0.08em] uppercase text-ink transition-colors hover:border-accent hover:text-accent"
              >
                Start a project
              </Link>
            </div>

            <div className="mt-16 flex w-full gap-3 overflow-x-auto no-scrollbar pb-2 sm:hidden">
              {floating.map((card) => (
                <figure
                  key={card.label}
                  className="w-[42vw] shrink-0 overflow-hidden rounded-xl bg-white shadow-lg ring-1 ring-black/5"
                >
                  <img src={card.src} alt={card.label} className="aspect-[4/5] w-full object-cover" />
                  <figcaption className="px-3 py-2 text-[10px] tracking-[0.16em] uppercase text-mute">
                    {card.label}
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-stone bg-white py-5 overflow-hidden">
        <div className="flex w-max marquee-track">
          {[0, 1].map((copy) => (
            <div key={copy} className="flex items-center">
              {capabilities.map((item) => (
                <span key={`${copy}-${item}`} className="flex items-center">
                  <span className="px-6 text-[13px] tracking-[0.28em] uppercase text-ink">
                    {item}
                  </span>
                  <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 py-24 md:px-8 md:py-36">
        <Reveal>
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">A statement</p>
          <h2 className="mt-6 max-w-5xl font-serif text-[11vw] leading-[0.95] tracking-[-0.03em] text-ink sm:text-6xl md:text-7xl lg:text-[84px]">
            We don’t decorate brands.
            <span className="italic text-mute"> We give them a spine — </span>
            then we put them in the world.
          </h2>
        </Reveal>
        <Reveal delay={120}>
          <div className="mt-16 grid gap-10 border-t border-stone pt-12 md:grid-cols-12">
            <p className="text-[13px] tracking-[0.16em] uppercase text-mute md:col-span-4">
              Built in Lahore.
              <br />
              Made for the world.
            </p>
            <p className="max-w-xl text-[17px] leading-[1.7] text-ink/80 md:col-span-8 md:text-[18px]">
              Pakworx sits between culture and commerce. We work with founders
              and teams who want more than a campaign — they want a way of being
              seen. That takes taste, strategy, and the patience to finish.
            </p>
          </div>
        </Reveal>
      </section>

      <section className="border-t border-stone">
        <div className="mx-auto max-w-[1480px] px-5 py-20 md:px-8 md:py-28">
          <div className="mb-14 flex items-end justify-between gap-6">
            <Reveal>
              <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Capabilities</p>
              <h2 className="mt-3 font-serif text-5xl tracking-tight md:text-6xl">
                What we hold.
              </h2>
            </Reveal>
            <Reveal>
              <Link
                to="/services"
                className="hidden text-[13px] tracking-[0.1em] uppercase text-mute transition-colors hover:text-accent md:inline-flex"
              >
                All services ↗
              </Link>
            </Reveal>
          </div>

          <div className="divide-y divide-stone border-y border-stone">
            {previewServices.map((service, i) => (
              <Link
                key={service.id}
                to="/services"
                className="group grid items-center gap-6 py-8 md:grid-cols-12 md:py-10"
              >
                <span className="text-[12px] tracking-[0.18em] text-mute md:col-span-1">
                  {service.index}
                </span>
                <h3 className="font-serif text-4xl tracking-tight transition-colors group-hover:text-accent md:col-span-3 md:text-5xl">
                  {service.name}
                </h3>
                <p className="text-[16px] leading-relaxed text-mute md:col-span-5">
                  {service.tagline}
                </p>
                <div className="flex items-center justify-between md:col-span-3 md:justify-end">
                  <div className="relative h-16 w-24 overflow-hidden rounded-lg opacity-0 transition-all duration-500 group-hover:opacity-100 max-md:hidden">
                    <img
                      src={service.image}
                      alt=""
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                  <span className="ml-6 text-sm text-mute transition-all group-hover:translate-x-1 group-hover:text-accent">
                    0{i + 1}
                  </span>
                </div>
              </Link>
            ))}
          </div>
          <Link
            to="/services"
            className="mt-8 inline-flex text-[13px] tracking-[0.1em] uppercase text-mute md:hidden"
          >
            All services ↗
          </Link>
        </div>
      </section>

      <section className="bg-ink text-white">
        <div className="mx-auto max-w-[1480px] px-5 py-20 md:px-8 md:py-28">
          <div className="mb-12 flex items-end justify-between">
            <Reveal>
              <p className="text-[11px] tracking-[0.22em] uppercase text-white/40">Selected</p>
              <h2 className="mt-3 font-serif text-5xl tracking-tight md:text-6xl">
                Recent work.
              </h2>
            </Reveal>
            <Link
              to="/portfolio"
              className="hidden text-[13px] tracking-[0.1em] uppercase text-white/50 transition-colors hover:text-white md:inline-flex"
            >
              Full portfolio ↗
            </Link>
          </div>

          <div className="grid gap-4 md:grid-cols-12 md:gap-5">
            {projects.slice(0, 3).map((project, i) => (
              <Link
                key={project.id}
                to={`/portfolio/${project.id}`}
                className={`group relative overflow-hidden rounded-2xl ${
                  i === 0 ? "md:col-span-7 md:h-[560px]" : i === 1 ? "md:col-span-5 md:h-[560px]" : "md:col-span-12 md:h-[420px]"
                } h-[380px]`}
              >
                <img
                  src={project.image}
                  alt={project.name}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
                  <p className="text-[11px] tracking-[0.2em] uppercase text-white/70">
                    {project.category} · {project.year}
                  </p>
                  <h3 className="mt-2 font-serif text-3xl md:text-4xl">{project.name}</h3>
                </div>
              </Link>
            ))}
          </div>
          <Link
            to="/portfolio"
            className="mt-8 inline-flex text-[13px] tracking-[0.1em] uppercase text-white/60 md:hidden"
          >
            Full portfolio ↗
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 py-24 md:px-8 md:py-36">
        <Reveal>
          <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Philosophy</p>
          <h2 className="mt-3 max-w-2xl font-serif text-5xl tracking-tight md:text-6xl">
            How we sit with a problem.
          </h2>
        </Reveal>
        <div className="mt-20 divide-y divide-stone border-y border-stone">
          {philosophy.map((item, i) => (
            <Reveal key={item.num} delay={i * 70} className="grid gap-4 py-10 md:grid-cols-12 md:items-baseline md:gap-8 md:py-14">
              <span className="font-serif text-4xl text-accent/80 md:col-span-2">{item.num}</span>
              <h3 className="font-serif text-3xl md:col-span-3 md:text-4xl">{item.title}</h3>
              <p className="text-[16px] leading-[1.7] text-mute md:col-span-7 md:text-[17px]">{item.text}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="px-3 pb-3 md:px-4 md:pb-4">
        <div className="relative overflow-hidden rounded-[28px] bg-mist px-6 py-24 text-center md:rounded-[40px] md:py-32">
          <div className="pointer-events-none absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/20 blur-[100px]" />
          <Reveal>
            <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Next</p>
            <h2 className="mt-5 font-serif text-5xl tracking-tight md:text-7xl">
              Have something
              <br />
              <em className="italic">in mind?</em>
            </h2>
            <Link
              to="/contact"
              className="mt-10 inline-flex items-center gap-2 rounded-full bg-ink px-8 py-4 text-[13px] tracking-[0.1em] uppercase text-white transition-colors hover:bg-accent"
            >
              Let’s talk ↗
            </Link>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
