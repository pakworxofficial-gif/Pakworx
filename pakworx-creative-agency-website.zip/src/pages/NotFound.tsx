import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="page-enter flex min-h-screen flex-col items-center justify-center px-5 text-center">
      <p className="text-[11px] tracking-[0.22em] uppercase text-mute">404</p>
      <h1 className="mt-4 font-serif text-6xl md:text-8xl">Lost the frame.</h1>
      <Link to="/" className="mt-8 text-[13px] tracking-[0.12em] uppercase text-accent">
        Back home ↗
      </Link>
    </div>
  );
}
