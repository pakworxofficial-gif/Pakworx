import { Link } from "react-router-dom";
import { projects } from "../data/content";
import { cn } from "../utils/cn";

const spanClass: Record<string, string> = {
  large: "md:col-span-8 md:row-span-2 min-h-[520px]",
  wide: "md:col-span-8 min-h-[380px]",
  tall: "md:col-span-4 md:row-span-2 min-h-[520px]",
  small: "md:col-span-4 min-h-[380px]",
};

export default function Portfolio() {
  return (
    <div className="page-enter bg-paper">
      <section className="mx-auto max-w-[1480px] px-5 pb-12 pt-32 md:px-8 md:pt-40">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div>
            <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Portfolio</p>
            <h1 className="mt-5 font-serif text-[15vw] leading-[0.86] tracking-[-0.04em] sm:text-7xl md:text-8xl">
              Selected
              <br />
              <em className="italic">studies.</em>
            </h1>
          </div>
          <p className="max-w-xs text-[15px] leading-relaxed text-mute md:mb-2">
            A mix of identity, film, design, and digital. Visuals first. The
            rest is in the case.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-3 pb-20 md:px-4 md:pb-28">
        <div className="grid auto-rows-fr gap-3 md:grid-cols-12">
          {projects.map((project) => (
            <Link
              key={project.id}
              to={`/portfolio/${project.id}`}
              className={cn(
                "group relative min-h-[420px] overflow-hidden rounded-2xl bg-mist",
                spanClass[project.size],
              )}
            >
              <img
                src={project.image}
                alt={project.name}
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6 md:p-8">
                <div>
                  <p className="text-[11px] tracking-[0.2em] uppercase text-white/65">
                    {project.category}
                  </p>
                  <h2 className="mt-1 font-serif text-3xl text-white md:text-4xl">
                    {project.name}
                  </h2>
                </div>
                <span className="translate-y-2 text-white/0 transition-all duration-300 group-hover:translate-y-0 group-hover:text-white">
                  ↗
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
