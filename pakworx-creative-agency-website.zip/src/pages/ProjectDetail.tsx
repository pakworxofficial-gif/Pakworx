import { Link, useParams } from "react-router-dom";
import { projects } from "../data/content";

export default function ProjectDetail() {
  const { id } = useParams();
  const project = projects.find((p) => p.id === id);
  const index = projects.findIndex((p) => p.id === id);
  const next = projects[(index + 1) % projects.length];

  if (!project) {
    return (
      <div className="page-enter mx-auto max-w-3xl px-5 py-40">
        <h1 className="font-serif text-5xl">Work not found.</h1>
        <Link to="/portfolio" className="mt-6 inline-block text-accent">
          Back to portfolio ↗
        </Link>
      </div>
    );
  }

  return (
    <div className="page-enter bg-paper">
      <section className="relative h-[78vh] min-h-[520px] overflow-hidden bg-ink">
        <img src={project.image} alt={project.name} className="h-full w-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-[1480px] px-5 pb-12 md:px-8 md:pb-16">
          <p className="text-[11px] tracking-[0.22em] uppercase text-white/60">
            {project.category} · {project.year}
          </p>
          <h1 className="mt-3 font-serif text-6xl text-white md:text-8xl">{project.name}</h1>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1480px] gap-12 px-5 py-20 md:grid-cols-12 md:px-8 md:py-28">
        <div className="md:col-span-4">
          <p className="text-[11px] tracking-[0.2em] uppercase text-mute">The work</p>
          <dl className="mt-8 space-y-5">
            <div>
              <dt className="text-[12px] tracking-[0.16em] uppercase text-mute">Discipline</dt>
              <dd className="mt-1 text-[17px]">{project.category}</dd>
            </div>
            <div>
              <dt className="text-[12px] tracking-[0.16em] uppercase text-mute">Year</dt>
              <dd className="mt-1 text-[17px]">{project.year}</dd>
            </div>
            <div>
              <dt className="text-[12px] tracking-[0.16em] uppercase text-mute">Studio</dt>
              <dd className="mt-1 text-[17px]">Pakworx, Lahore</dd>
            </div>
          </dl>
        </div>
        <div className="md:col-span-7 md:col-start-6">
          <p className="font-serif text-3xl leading-snug tracking-tight md:text-4xl">
            {project.description}
          </p>
          <p className="mt-8 text-[17px] leading-[1.75] text-mute">
            This case is presented as a study — the thinking, the frames, and
            the system around them. Full process notes live with the team. If
            you want to walk through it, write to us.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1480px] px-5 pb-24 md:px-8">
        <div className="grid gap-4 md:grid-cols-12">
          <div className="overflow-hidden rounded-2xl md:col-span-7">
            <img src={project.image} alt="" className="aspect-[4/5] w-full object-cover md:aspect-[4/3]" />
          </div>
          <div className="overflow-hidden rounded-2xl md:col-span-5">
            <img
              src={project.secondary}
              alt=""
              className="aspect-[4/5] w-full object-cover"
            />
          </div>
        </div>
      </section>

      <section className="border-t border-stone">
        <Link
          to={`/portfolio/${next.id}`}
          className="group mx-auto flex max-w-[1480px] items-end justify-between px-5 py-16 md:px-8"
        >
          <div>
            <p className="text-[11px] tracking-[0.2em] uppercase text-mute">Next study</p>
            <h2 className="mt-3 font-serif text-4xl transition-colors group-hover:text-accent md:text-6xl">
              {next.name}
            </h2>
          </div>
          <span className="text-2xl transition-transform group-hover:translate-x-1">↗</span>
        </Link>
      </section>
    </div>
  );
}
