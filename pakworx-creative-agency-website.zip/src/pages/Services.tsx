import { useState } from "react";
import { Link } from "react-router-dom";
import { services } from "../data/content";
import { cn } from "../utils/cn";

export default function Services() {
  const [active, setActive] = useState(services[0].id);
  const current = services.find((s) => s.id === active) ?? services[0];

  return (
    <div className="page-enter bg-paper">
      <section className="mx-auto max-w-[1480px] px-5 pb-10 pt-32 md:px-8 md:pt-40">
        <p className="text-[11px] tracking-[0.22em] uppercase text-mute">Services</p>
        <div className="mt-6 flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <h1 className="max-w-3xl font-serif text-[14vw] leading-[0.88] tracking-[-0.04em] sm:text-7xl md:text-8xl">
            What we
            <br />
            actually do.
          </h1>
          <p className="max-w-sm text-[16px] leading-relaxed text-mute lg:mb-3">
            Six practices. One standard. Choose a discipline — the work changes
            shape, the thinking does not.
          </p>
        </div>
      </section>

      <section className="border-t border-stone">
        <div className="mx-auto grid max-w-[1480px] lg:grid-cols-12">
          <aside className="border-b border-stone lg:col-span-4 lg:border-b-0 lg:border-r">
            <div className="lg:sticky lg:top-20">
              <div className="flex gap-2 overflow-x-auto no-scrollbar px-5 py-4 lg:hidden">
                {services.map((service) => (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => setActive(service.id)}
                    className={cn(
                      "shrink-0 rounded-full border px-4 py-2 text-[12px] tracking-[0.12em] uppercase",
                      active === service.id
                        ? "border-ink bg-ink text-white"
                        : "border-stone text-mute",
                    )}
                  >
                    {service.name}
                  </button>
                ))}
              </div>
              <nav className="hidden lg:block">
                {services.map((service) => (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => setActive(service.id)}
                    className={cn(
                      "flex w-full items-baseline justify-between border-b border-stone px-8 py-6 text-left transition-colors",
                      active === service.id ? "bg-mist" : "hover:bg-mist/60",
                    )}
                  >
                    <span
                      className={cn(
                        "font-serif text-4xl tracking-tight",
                        active === service.id ? "text-ink" : "text-mute",
                      )}
                    >
                      {service.name}
                    </span>
                    <span
                      className={cn(
                        "text-[12px] tracking-[0.16em]",
                        active === service.id ? "text-accent" : "text-mute",
                      )}
                    >
                      {service.index}
                    </span>
                  </button>
                ))}
              </nav>
            </div>
          </aside>

          <div className="lg:col-span-8">
            <article className="px-5 py-10 md:px-12 md:py-14">
              <div className="overflow-hidden rounded-2xl">
                <img
                  key={current.image}
                  src={current.image}
                  alt={current.name}
                  className="aspect-[16/9] w-full object-cover page-enter"
                />
              </div>

              <p className="mt-10 font-serif text-3xl leading-snug tracking-tight md:text-4xl">
                {current.tagline}
              </p>

              <div className="mt-12 grid gap-12 md:grid-cols-2">
                <div>
                  <p className="text-[11px] tracking-[0.2em] uppercase text-accent">What it is</p>
                  <p className="mt-4 text-[16px] leading-[1.75] text-ink/80">{current.what}</p>
                </div>
                <div>
                  <p className="text-[11px] tracking-[0.2em] uppercase text-accent">Why it matters</p>
                  <p className="mt-4 text-[16px] leading-[1.75] text-ink/80">{current.why}</p>
                </div>
              </div>

              <div className="mt-12 border-t border-stone pt-10">
                <p className="text-[11px] tracking-[0.2em] uppercase text-accent">
                  What Pakworx delivers
                </p>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {current.delivers.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[16px] text-ink">
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="border-t border-stone bg-ink text-white">
        <div className="mx-auto flex max-w-[1480px] flex-col items-start justify-between gap-8 px-5 py-20 md:flex-row md:items-center md:px-8">
          <h2 className="max-w-xl font-serif text-4xl tracking-tight md:text-5xl">
            Not sure where to start? Bring the problem. We’ll name the work.
          </h2>
          <Link
            to="/contact"
            className="rounded-full bg-white px-7 py-3 text-[13px] tracking-[0.1em] uppercase text-ink transition-colors hover:bg-accent hover:text-white"
          >
            Let’s talk ↗
          </Link>
        </div>
      </section>
    </div>
  );
}
